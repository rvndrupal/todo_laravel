<?php $__env->startSection('content'); ?>

    <div class="col-sm-8">
        <h2>Listado de Productos
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary pull-right">Nuevo</a>
        </h2>

    <?php echo $__env->make('products.fragment.info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th width="20px">ID</th>
                <th>Nombre del Producto</th>
                <th colspan="3">&nbsp;</th>

            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($p->id); ?></th>
                    <th><strong><?php echo e($p->name); ?></strong>
                        <?php echo e($p->short); ?>

                    
                    </th>
                    <th>
                        <a href="<?php echo e(route('products.show', $p->id)); ?>" class="btn btn-default">Ver</a>
                    </th>
                    <th>
                        <a href="<?php echo e(route('products.edit', $p->id)); ?>" class="btn btn-success">Editar</a>
                    </th>
                    <th>
                        <form action="<?php echo e(route('products.destroy', $p->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="DELETE">
                            <button class="btn btn-danger">Borrar</button>
                        </form>

                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        
    <?php echo $pro->render(); ?>



    </div>

    <div class="col-sm-4">
            <?php echo $__env->make('products.fragment.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>