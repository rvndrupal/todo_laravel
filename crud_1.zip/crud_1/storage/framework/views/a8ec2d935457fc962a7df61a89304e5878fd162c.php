<?php $__env->startSection('content'); ?>

    <div class="col-sm-8">
        <h2>
            <?php echo e($pro->name); ?>

            <a href="<?php echo e(route('products.edit', $pro->id)); ?>" class="btn btn-default pull-right">Editar</a>
        </h2>
        <p>
            <?php echo e($pro->short); ?>

        </p>
        <hr>
        <br>
        <?php echo $pro->body; ?>

    


    </div>

    <div class="col-sm-4">
            <?php echo $__env->make('products.fragment.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>