<div class="form-froup">
    
    <?php echo Form::label('name', 'Nombre del Producto'); ?>

    
    <?php echo Form::text('name', null, ['class'=>'form-control']); ?>    
    
</div>

<div class="form-froup">
    
    <?php echo Form::label('short', 'Descripción Breve del Producto'); ?>

    
    <?php echo Form::text('short', null, ['class'=>'form-control']); ?>    
    
</div>

<div class="form-froup">
    
    <?php echo Form::label('body', 'Descripción del Producto'); ?>

    
    <?php echo Form::textarea('body', null, ['class'=>'form-control']); ?>    
    
</div>

<div class="form-froup">
    
    <?php echo Form::submit('ENVIAR', ['class'=>'btn btn-primary']); ?>

    
    
    
</div>