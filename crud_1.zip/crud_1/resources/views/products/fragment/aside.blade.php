<p class="alert alert-info">
    Desde aquí Podemos Crear, Eliminar, Listar y Editar los productos.
</p>